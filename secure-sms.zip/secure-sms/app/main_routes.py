from collections import Counter
from flask import Blueprint, render_template, session, redirect, url_for
from flask_login import login_required, current_user
from .models import Student

main_bp = Blueprint("main", __name__)

@main_bp.route("/")
def index():
    return redirect(url_for("auth.login"))

@main_bp.route("/dashboard")
@login_required
def dashboard():
    # Require biometric completion
    if not session.get("bio_ok"):
        return redirect(url_for("auth.biometric"))
    # Compute grade distribution
    grades = [s.grade for s in Student.query.all() if s.grade]
    counts = Counter(grades)
    labels = ["A","B","C","D","F"]
    data = [counts.get(k, 0) for k in labels]
    return render_template("dashboard.html", labels=labels, data=data)
